// Hussein's Binary Tree
// 26 March 2017
// Hussein Suleman
/**
 * 
 * @author Siphosakhe Mahlangu
 *
 * @param <dataType>
 */
public class BinaryTreeNode<dataType>
{
   dataType data;
   BinaryTreeNode<dataType> left;
   BinaryTreeNode<dataType> right;
   public int height;
   
   
   public BinaryTreeNode ( dataType d, BinaryTreeNode<dataType> l, BinaryTreeNode<dataType> r )
   {
      data = d;
      left = l;
      right = r;
   }
   
   /**
    *THe class that returns the right or left node 
    * @return
    */
   BinaryTreeNode<dataType> getLeft () { return left; }
   BinaryTreeNode<dataType> getRight () { return right; }

}
