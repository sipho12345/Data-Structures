// Hussein's AVL Tree
// 2 April 2017
// Hussein Suleman
// reference: kukuruku.co/post/avl-trees/

/**
 * The AVLTree class
 * @author Siphosake Mahlangu
 *
 * @param <dataType>
 */

public class AVLTree<dataType extends Comparable<? super dataType>> extends BinaryTree<dataType>
{
   public static final String l = null;
   public static final String data = null;
   public int h = 0;
   
   /**
    * The method returning the height
    * 
    * @param node of type BinaryTreeNode<dataType>
    * @return
    */
public int height ( BinaryTreeNode<dataType> node )
   {
      if (node != null)
         return node.height;
      return -1;
   }
   /**
    * The balance factor method
    * @param node the node parameter
    * @return the height return
    */
   public int balanceFactor ( BinaryTreeNode<dataType> node )
   {
      return height (node.right) - height (node.left);
   }
   /**
    * The fix height method
    * @param node the node parameter
    */
   public void fixHeight ( BinaryTreeNode<dataType> node )
   {
      node.height = Math.max (height (node.left), height (node.right)) + 1;
   }
   /**
    * The right rotation method
    * @param p the parameter tree
    * @return
    */
   public BinaryTreeNode<dataType> rotateRight ( BinaryTreeNode<dataType> p )
   {
      BinaryTreeNode<dataType> q = p.left;
      p.left = q.right;
      q.right = p;
      fixHeight (p);
      fixHeight (q);
      return q;
   }
   /**
    * The rotate left method
    * @param q the q parameter
    * @return return the p
    */
   public BinaryTreeNode<dataType> rotateLeft ( BinaryTreeNode<dataType> q )
   {
      BinaryTreeNode<dataType> p = q.right;
      q.right = p.left;
      p.left = q;
      fixHeight (q);
      fixHeight (p);
      return p;
   }
   /**
    * The balance method
    * @param node entry parameter
    * @return returns the entry
    */
   
   public BinaryTreeNode<dataType> balance ( BinaryTreeNode<dataType> node )
   {
      fixHeight (node);
      if (balanceFactor (node) == 2)
      {
         if (balanceFactor (node.right) < 0)
            node.right = rotateRight (node.right);
         return rotateLeft (node);
      }
      if (balanceFactor (node) == -2)
      {
         if (balanceFactor (node.left) > 0)
            node.left = rotateLeft (node.left);
         return rotateRight (node);
      }
      return node;
   }
   /**
    * The insert method for inserting the elements
    * @param d parameter d of type dataType
    */
   public void insert ( dataType d )
   {  
      	 
      root = insert (d, root);
   }
   /**
    * 
    * @param d parameter d of type dataType
    * @param node the parameter node
    * @return return the balanced node
    */
   public BinaryTreeNode<dataType> insert ( dataType d, BinaryTreeNode<dataType> node )
   {
      h++;  
      if (node == null)
         return new BinaryTreeNode<dataType> (d, null, null);
      if (d.compareTo (node.data) <= 0)
         node.left = insert (d, node.left);
      else
         node.right = insert (d, node.right);
      return balance (node);
   }
   /**
    * The delete method used to delete the elements
    * @param d the parameter d of type dataType
    */
   
   public void delete ( dataType d )
   {
      root = delete (d, root);
   }
   /**
    *  
    * @param d parameter d of type dataType 
    * @param node parameter node of type BinaryTreeNode<dataType>
    * @return returns the balanced nodes
    */
   public BinaryTreeNode<dataType> delete ( dataType d, BinaryTreeNode<dataType> node )
   {
      if (node == null) return null;
      if (d.compareTo (node.data) < 0)
         node.left = delete (d, node.left);
      else if (d.compareTo (node.data) > 0)
         node.right = delete (d, node.right);
      else
      {
         BinaryTreeNode<dataType> q = node.left;
         BinaryTreeNode<dataType> r = node.right;
         if (r == null)
            return q;
         BinaryTreeNode<dataType> min = findMin (r);
         min.right = removeMin (r);
         min.left = q;
         return balance (min);
      }
      return balance (node);
   }
   /**
    * The findMin method to find the minimum value
    */
   public BinaryTreeNode<dataType> findMin ( BinaryTreeNode<dataType> node )
   {
      if (node.left != null)
         return findMin (node.left);
      else
         return node;
   }
   /**
    * The remove minimum method
    * @param node the node parameter of type BinaryTreeNode<dataType>
    * @return returns the balanced node
    */

   public BinaryTreeNode<dataType> removeMin ( BinaryTreeNode<dataType> node )
   {
      if (node.left == null)
         return node.right;
      node.left = removeMin (node.left);
      return balance (node);
   }
   /**
    * The find method
    * @param d the parameter of type dataType 
    * @return returns the root d
    */

   public BinaryTreeNode<dataType> find ( dataType d )
   { 
	  //h++;
      if (root == null)
         return null;
      else
         return find (d, root);
   }
   /**
    * The find method
    * @param d
    * @param node
    * @return
    */
   public BinaryTreeNode<dataType> find ( dataType d, BinaryTreeNode<dataType> node )
   {
	  //h++;
      if (d.compareTo (node.data) == 0) 
         return node;
      else if (d.compareTo (node.data) < 0)
         return (node.left == null) ? null : find (d, node.left);
      else
         return (node.right == null) ? null : find (d, node.right);
      
   }
   /**
    * TreeOrder method
    */
   
   public void treeOrder ()
   {
      treeOrder (root, 0);
   }
   /**
    * The treeOrder
    * @param node the node parameter
    * @param level the level parameter
    */
   public void treeOrder ( BinaryTreeNode<dataType> node, int level )
   {
      if (node != null)
      {
         for ( int i=0; i<level; i++ )
         System.out.print (" ");
         System.out.println (node.data);
         treeOrder (node.left, level+1);
         treeOrder (node.right, level+1);
      }
   }
}

