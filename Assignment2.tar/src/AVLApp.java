import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.Scanner;
/**
 * The is the AVLtreeApp that balances itself after inserting an element 
 * @author Siphosakhe Mahlangu
 *
 */
public class AVLApp {
    public static Scanner scanner;
    public static int l = 0;
    public String[] array = new String[2976];
    static AVLTree<Entry> avl1 = new AVLTree<Entry>();
    BinarySearchTree<Entry> bst = new BinarySearchTree<Entry>();
    /**
     * The main method of the AVLApp class 
     * @param <String> String parameter  
     * @param <File> File type parameter
     * @param args arguments in an AVLApp main method
     */
    
    public static void main(String[] args) {
        AVLApp a = new AVLApp();
        Entry temp = null;
        try {
            File file = new File("Load_Shedding_All_Areas_Schedule_and_Map.clean.final.txt");
            scanner = new Scanner(file);
            int i = 0;
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                temp = new Entry(line);
                a.avl1.insert(new Entry(line));
                i++;
            }

        } catch (FileNotFoundException e) {
            System.out.println("File Not Found");
        }
        if (args.length > 0) {
            a.printArea(args[0], args[1], args[2]);
        }
        else {
            a.printAllArea();
        }
         try{
            a.makefile();
            } catch(Exception e){
                System.out.println("File not created");
            }
    }
  	
	/**
     * The method prints out the areas that match
     * @param stage stage parameter
     * @param day day parameter
     * @param startTime start time parameter
     */
    public void printArea(String stage, String day, String startTime) {
      String slot = stage+"_"+day+"_"+startTime;
      BinaryTreeNode<Entry> node = avl1.find(new Entry(slot, null));
      System.out.println("The matching Area(s) are: "+node.data.getArea());
      System.out.println(avl1.h);
	}
    /**
     * Method to print all areas regardless of whether or not they match
     */
    public void printAllArea() {
        System.out.println(avl1.h);
		avl1.inOrder();
    }
    /**
     * Make file method to create a file to be used for count
     * @throws IOException throw
     */
    public void makefile()throws IOException{
      File file = new File("countresults.txt");
      PrintWriter pw = new PrintWriter(file);
      pw.println(avl1.h);
      pw.close();
     }
    }

