// Hussein's Binary Tree
// 26 March 2017
// Hussein Suleman

/**
 * The BTQueueNode class
 * @author Siphosakhe Mahlangu
 *
 * @param <dataType>
 */

public class BTQueueNode<dataType>
{
   BinaryTreeNode<dataType> node;
   BTQueueNode<dataType> next;
   
   public BTQueueNode ( BinaryTreeNode<dataType> n, BTQueueNode<dataType> nxt )
   {
      node = n;
      next = nxt;
   }
}
