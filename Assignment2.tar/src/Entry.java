/**
 * Entry class that holds the data from the file
 * @author Siphosakhe Mahlangu
 *
 */
public class Entry implements Comparable<Entry> {
	
	public String slot;
	public String area;
	/**
	 * The constructor of the class Entry
	 * @param slot the slot parameter
	 * @param area the area parameter
	 */
	
    public Entry(String slot, String area) {
    	this.slot = slot;
    	this.area = area;
    }
    /**
     * The second constructor of the class Entry
     * @param line The line parameter
     */
    public Entry(String line) {
    	slot = line.substring(0,line.indexOf(" "));
    	area = line.substring(line.indexOf(" ")+1);
	}
    /**
     * The method that return the slot
     * @return return the slot
     */
    public String getslot() {
    	return slot;
    }
    /**
     * Method to return the area
     * @return return the area
     */
    public String getArea() {
    	return area;
    }
    /**
     * The compare to method
     */
    public int compareTo(Entry other) {
    	String[] firstlist = (this.slot).split("_");
    	String[] second = (other.getslot()).split("_");
    	int date1 = Integer.parseInt(firstlist[1]);
    	int date2 = Integer.parseInt(second[1]);
    	if(date1 < date2) {
    		return -1;
    	}
    	else if(date1 > date2) {
			return 1;
		}
    	else
    		return 0;
    }
    /**
     * The to string method returning the string
     * @return the area return method
     */
	public String toString(){
    	return area;
	}
}
