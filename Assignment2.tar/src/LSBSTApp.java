import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.Scanner;

/**
 * A linear binary search tree class
 * @author Siphosakhe Mahlangu
 *
 */
public class LSBSTApp {
    public static Scanner scanner;
   
    public String[] array = new String[2976];
    BinarySearchTree<Entry> binary = new BinarySearchTree<Entry>();
    public int total;
    public int average;  
    public static void main(String[] args) {
        LSBSTApp b = new LSBSTApp();
        Entry temp = null;
        try {
            File file = new File("Load_Shedding_All_Areas_Schedule_and_Map.clean.final.txt");
            scanner = new Scanner(file);
            int i = 0;
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                temp = new Entry(line);
                b.binary.insert(new Entry(line));
                i++;
            }

        } catch (FileNotFoundException e) {
            System.out.println("File Not Found");
        }
        if (args.length > 0) {
            b.printArea(args[0], args[1], args[2]);
        }
        else {
            b.printAllArea();
        }
         try{
            b.makefile();
            } catch(Exception e){
                System.out.println("File not created");
            }
    }
    /**
     * Method to to print all matching areas
     * @param the stage parameter
     * @param the day parameter 
     * @param the startTime parameter
     */
    public void printArea(String stage, String day, String startTime) {
      String slot = stage+"_"+day+"_"+startTime;
      BinaryTreeNode<Entry> node = binary.find(new Entry(slot, null));
      System.out.println("The matching Area(s) are: "+node.data.getArea());
      System.out.println(binary.l);
    
	}
   
    /**
     * Method to print all areas
     */
    public void printAllArea() {
        //System.out.println(binary.l);
		binary.inOrder();
    }
    /**
     * Method to create a file
     * @throws IOException throw
     */
    public void makefile()throws IOException{
      File file = new File("countresults.txt");
      PrintWriter pw = new PrintWriter(file);
      pw.print(binary.l);
      pw.close();
    }
 
}


