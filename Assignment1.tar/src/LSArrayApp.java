import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.Scanner;

public class LSArrayApp{
    String stage1;
    String day1;
    String time1;
    String Areas;
    int l = 0;
    public String[] array = new String[2976];
    public static void main(String[] args){
        LSArrayApp t = new LSArrayApp ();

            try {
                File file = new File("Test.txt");
                Scanner scanner = new Scanner(file);
                int i = 0;
                while (scanner.hasNextLine()) {

                    t.array[i] = scanner.nextLine();
                    i++;
                }
            } catch (FileNotFoundException e) {
                System.out.println("File Not Found");
            }

            if(args.length>0){

            t.printAreas(args[0], args[1], args[2]);
            }
            else{
            t.printAllAreas();
            }
            try{
            t.makefile();
            } catch(Exception e){
                System.out.println("File not created");
            }
    }
    public void printAreas(String stage, String day, String startTime){
        for(int j=0;j<2976;j++){
            int find_day = this.array[j].indexOf("_")+1;
            int find_time = this.array[j].lastIndexOf("_")+1;
            int find_space = this.array[j].indexOf(" ");
            this.stage1 = this.array[j].substring(0,find_day-1);
            this.day1 = this.array[j].substring(find_day,find_time-1);
            this.time1 = this.array[j].substring(find_time,find_space);
            if(stage.equals(stage1)&&day.equals(day1)&&startTime.equals(time1)){
                l++;
                Areas = this.array[j].substring(find_space+1);
                System.out.println("The matching Area(s) are: "+Areas);
                break;
                }
            else{
                System.out.println("Area not found");
                break;
             }
            }
          }
    
    public void printAllAreas(){
        for(int k =0;k<2976;k++) {
            int find_space1 = this.array[k].indexOf(" ");
            System.out.println("The Areas are: "+this.array[k].substring(find_space1+1));
        }
    }

    public void makefile()throws IOException{
      File file = new File("countresults.txt");
      PrintWriter pw = new PrintWriter(file);
      pw.println(l);
      pw.close();
    }
}
