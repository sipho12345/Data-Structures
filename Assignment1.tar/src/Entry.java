
public class Entry implements Comparable<Entry> {
	
	public String slot;
	public String area;
	
    public Entry(String slot, String area) {
    	this.slot = slot;
    	this.area = area;
    }
    public Entry(String line) {
    	slot = line.substring(0,line.indexOf(" "));
    	area = line.substring(line.indexOf(" ")+1);
	}
    public String getslot() {
    	return slot;
    }
    public String getArea() {
    	return area;
    }
    public int compareTo(Entry other) {
    	String[] firstlist = (this.slot).split("_");
    	String[] second = (other.getslot()).split("_");
    	int date1 = Integer.parseInt(firstlist[1]);
    	int date2 = Integer.parseInt(second[1]);
    	if(date1 < date2) {
    		return -1;
    	}
    	else if(date1 > date2) {
			return 1;
		}
    	else
    		return 0;
    }

	public String toString(){
    	return area;
	}
}
