#!/out/bash
for i {297..2976..297}
   do 
       cat Test.txt | head -n $i >"text"$i".txt"

   done