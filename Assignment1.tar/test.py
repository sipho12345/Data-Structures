import subprocess 

file = open("/home/m/mhlsip057/IdeaProjects/Assignment1")
file = open()

subprocess.call(["javac", "LSArrayApp"])

for line in file:
    line = line.strip('\n')
    otherArgs = line.split("_")
    cmdCall = cmdArgs +otherArgs
    subprocess.call(cmdCall, stdout = file2)
    
file.close()
file2.close()

file = open("/home/m/mhlsip057/IdeaProjects/Assignment1/values")

result = []

for line in file:
    avg = sum(results)/len(results)
    min_value = min(results)
    max_value = max(results)
    
    print("Min ", min_value)
    print("Average ", avg)
    print("Max ", max_value)