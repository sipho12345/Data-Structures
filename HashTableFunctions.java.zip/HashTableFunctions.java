import java.util.Arrays;

/**
 * This is the HashTableFunction class containing the hash and find function methods 
 */

class HashTableFunctions
{
   
   int hashTableSize;
   String [] hashTableArray;
   String element_s;
   int ArrayIndex;
   int ArrayIndexHash;
   // constructor
   public HashTableFunctions ( int size, String [] array )
   {
      hashTableSize = size;
      hashTableArray = array;
      
   }

   // hash function
   
   /**
    * Populate the array everytime the method hash is invoked with the strings
    */
   public int hash ( String s )
   {
	   int sum = 0;
	   for(int i = 0;i<s.length();i++) 
	   {    
		   int newChar = s.charAt(i);
		   sum += newChar;
		   ArrayIndex = sum%hashTableSize;
		   
		   for(int k = 0;k<hashTableArray.length;k++) {
			  
			  if(!hashTableArray[ArrayIndex].equals("")){
			  ArrayIndex++;
			  ArrayIndex = ArrayIndex%hashTableSize; 
		   }
	     }
       }
	return ArrayIndex;  
   }
   // return True if the hash table contains string s
   // return False if the hash table does not contain string s
   /**
    * The method is used to find the string s, return false if not found in the hash table true otherwise
    */
   public boolean find ( String s )
   {    
	   int sum1 = 0;
	   for(int k = 0;k<s.length();k++) 
	   {    
		   int newChar1 = s.charAt(k);
		   sum1 += newChar1;
		   ArrayIndexHash = sum1%hashTableSize;
      
           for(int j = 0;j<hashTableArray.length; j++) {
    	      if(hashTableArray[ArrayIndexHash] == s){
    		     return true;
    	  }
    	  ++ArrayIndexHash;
    	  ArrayIndexHash %=hashTableSize;
      }
      //return false;
   }
	   return false;
  }
}